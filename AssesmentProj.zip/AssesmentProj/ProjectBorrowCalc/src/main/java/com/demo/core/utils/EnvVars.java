package com.demo.core.utils;




public class EnvVars {

	public static String DEFAULT_URL;
	
	public static String BROWSER;	 

	static {
		DEFAULT_URL = getExtProperty("DEFAULT_URL");		
		BROWSER = getExtProperty("BROWSER");

	}

	/**
	 * Get environment variables
	 * @return - Property value.
	 */
	private static String getExtProperty(String propName) {
		String prop = System.getenv(propName);

		if (prop == null || prop.equals("${" + propName + "}") || prop.isEmpty()) {
			System.out.println("Param '" + propName + "' is not defined at CI/CD job and = '" + prop
					+ "'. Getting value from config.properties file.");
			prop = Utils.getPropertyValue(propName);
			if (prop == null) {
				System.err.println("Param '" + propName + "' is missed (at CI/CD, "
						+ "config.properties) and will be set to null.");
			}
		}
		return prop;
	}
	
	

}
