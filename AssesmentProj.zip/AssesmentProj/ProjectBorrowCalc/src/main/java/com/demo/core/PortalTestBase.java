package com.demo.core;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.demo.core.utils.EnvVars;
import com.demo.core.utils.HtmlOps;
import com.demo.enums.DriverType;

public class PortalTestBase extends HtmlOps {
	public static String BROWSER = EnvVars.BROWSER;
	
	
	@BeforeMethod
	public void initDriver() throws InterruptedException {
		
		System.out.println("Initialising WebDriver");
		try {
			DriverType driverType = BROWSER.toUpperCase().equals("CHROME") ? DriverType.CHROME : DriverType.FIREFOX;

			DriverManager driverManager = DriverManagerFactory.getDriverManager(driverType);
			driver = driverManager.getDriver();
			driver.get(EnvVars.DEFAULT_URL);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(DEFAULT_UIELEMENT_WAIT_TIME, TimeUnit.SECONDS);

		} catch (NullPointerException ex) {
			throw new RuntimeException("Web driver could not be initialised for device ");
		}
	}

	/**
	 * Get instance of driver
	 *
	 * @return instance of driver
	 */
	public WebDriver getDriver() {
		return driver;
	}

	@AfterClass(alwaysRun = true)
	public void tearDownTestBaseAfterClass() {
			
			System.out.println("===========================================================================================\n\n");
			driver.quit();
		
		
	}

	@AfterMethod(alwaysRun = true)
	public void testBaseAfterMethod() {
		
		System.out.println("**** In AfterClass method END****");
		driver.close();
	}
}
