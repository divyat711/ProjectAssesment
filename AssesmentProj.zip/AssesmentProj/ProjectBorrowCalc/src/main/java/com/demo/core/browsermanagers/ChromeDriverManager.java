package com.demo.core.browsermanagers;

import java.util.Collections;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.demo.core.DriverManager;

import io.github.bonigarcia.wdm.WebDriverManager;

/** @author */
public class ChromeDriverManager extends DriverManager {
	/** Method to create instance of chrome driver */
	@Override
	protected void createDriver() {
		WebDriverManager.chromedriver().setup();

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--test-type");
		options.addArguments("ignore-certificate-errors");
		options.addArguments("--disable-single-click-autofill");
		options.addArguments("--ignore-autocomplete-off-autofill");

		options.setExperimentalOption("useAutomationExtension", false);
		options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		System.setProperty("webdriver.chrome.silentOutput", "true"); 
		this.driver = new ChromeDriver(options);
	}
}
