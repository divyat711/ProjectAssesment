package com.demo.core;
import com.demo.core.browsermanagers.ChromeDriverManager;
import com.demo.core.browsermanagers.FirefoxDriverManager;
import com.demo.enums.DriverType;
public class DriverManagerFactory {

	/**
	 * Method to create driver based on browser type and return instance of Driver
	 * Manager
	 *
	 * @return Instance of Driver Manager based on browser type passed
	 */
	public static DriverManager getDriverManager(DriverType driverType) {
		DriverManager driverManager;
		switch (driverType) {
		case CHROME:
			driverManager = new ChromeDriverManager();
			break;
		case FIREFOX:
			driverManager = new FirefoxDriverManager();
			break;

		default:
			driverManager = getDriverManager(DriverType.CHROME);
			break;
		}
		return driverManager;
	}
}
